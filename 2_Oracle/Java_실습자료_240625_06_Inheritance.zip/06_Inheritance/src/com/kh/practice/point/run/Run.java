package com.kh.practice.point.run;

import com.kh.practice.point.view.PointMenu;

public class Run {

	public static void main(String[] args) {
		PointMenu pm = new PointMenu();
		pm.mainMenu();		// mainMenu() 실행 => mainMenu() 메소드를 호출해라.

	}

}
